var module = angular.module('Diffind-DiffView', ['ngMaterial']);
	
module.controller('DiffindCtrl-DiffView', function($scope) {

  $scope.hasDiff = false;
  $scope.toggleDiffText = 'Show unified diff';
  $scope.toggleDiffViewIcon = 'settings_ethernet';
	
	$scope.toggleViewDiff = function(){
		var value = document.getElementById('visual').classList.toggle('jsondiffpatch-unchanged-hidden');
    $scope.toggleDiffViewIcon = !value ? 'code' : 'settings_ethernet';
    $scope.toggleDiffText = !value ? 'Show diff only' : 'Show unified diff';
	};

  var guid1 = JSON.parse(localStorage[getQueryVariable('guid1')]);
  var guid2 = JSON.parse(localStorage[getQueryVariable('guid2')]);

  $scope.guid1Title = guid1.title;
  $scope.guid2Title = guid2.title;

  var left = JSON.parse(guid1.json);
  var right = JSON.parse(guid2.json);

  var delta = jsondiffpatch.diff(left, right);

  if(delta === undefined){
    delta = 'No differences';
  } else {
    $scope.hasDiff = true;
    delta = jsondiffpatch.formatters.html.format(delta, left);
  }

  document.getElementById('visual').innerHTML = delta;
});

function getQueryVariable(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i=0;i<vars.length;i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  } 
}