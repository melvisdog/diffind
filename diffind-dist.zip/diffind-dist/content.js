chrome.extension.onMessage.addListener(function(message) {
	var response = pipeMessage(message);
	sendResponse(response, message);
});

function pipeMessage(message){
	switch(message.text){
		case 'fetch-capture':
			return handleFetchCapture(message);
	}
}

function sendResponse(response, message){
	response.text = response.text || message.text;
	var port = chrome.runtime.connect({name: "diffind-extension"});
	port.postMessage(response);
}

function handleFetchCapture(message){
	var data = window.document.getElementsByName(message.guid)[0].value;
	var hostname = location.hostname;
	
	return { data: data, guid: message.guid, hostname: hostname };
}